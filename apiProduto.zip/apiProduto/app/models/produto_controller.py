from flask import Blueprint


class ProdutoContoller:

    produto_controller = Blueprint(name="produto_controller", import_name=__name__)
