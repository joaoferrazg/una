host='localhost'
user='root'
password='anima123'
db='estoque'